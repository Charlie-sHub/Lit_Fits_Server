SELECT * FROM testlitfitsdb.material LIMIT 100;
