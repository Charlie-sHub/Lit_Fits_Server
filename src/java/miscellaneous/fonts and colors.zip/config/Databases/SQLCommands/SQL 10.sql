SELECT * FROM testlitfitsdb.garment_colors LIMIT 100;
