SELECT * FROM testlitfitsdb.company LIMIT 100;
