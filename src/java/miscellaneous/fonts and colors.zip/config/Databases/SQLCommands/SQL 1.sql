SELECT * FROM testlitfitsdb.color LIMIT 100;
