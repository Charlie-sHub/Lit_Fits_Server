SELECT * FROM testlitfitsdb.garment_materials LIMIT 100;
