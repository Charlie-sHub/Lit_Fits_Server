SELECT * FROM testlitfitsdb.garment LIMIT 100;
